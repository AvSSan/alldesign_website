from rest_framework import serializers
from .models import Testimonial
from django.conf import settings

class TestimonialSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = Testimonial
        fields = ['id', 'image', 'image_url', 'text', 'name']

    def get_image_url(self, obj):
        request = self.context.get('request')
        if obj.image and hasattr(obj.image, 'url'):
            print(request.build_absolute_uri(obj.image.url))
            return request.build_absolute_uri(obj.image.url)
        return None