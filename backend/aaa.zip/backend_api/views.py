from django.shortcuts import render
from .models import *
from django.http import HttpResponse
from rest_framework import generics
from .models import Testimonial
from .serializers import TestimonialSerializer


def index(request):
    return HttpResponse("Hello World")


class TestimonialListAPIView(generics.ListAPIView):
    queryset = Testimonial.objects.all()
    serializer_class = TestimonialSerializer

    def get_serializer_context(self):
        """Добавляем контекст запроса для формирования абсолютных URL."""
        return {'request': self.request}